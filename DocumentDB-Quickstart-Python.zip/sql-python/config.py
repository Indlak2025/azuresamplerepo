import os

settings = {
    'host': os.environ.get('ACCOUNT_HOST', 'https://nosqlser1.documents.azure.com:443/'),
    'master_key': os.environ.get('ACCOUNT_KEY', 'qy4FMdkxQKVVzZz5BjGB56IIx2o1kKrNCMf6FRdw2dyVdjPtM2XBAFWIQXTcKxjDzx9ZRgzTkWAvRRemfz8luQ=='),
    'database_id': os.environ.get('COSMOS_DATABASE', 'ToDoList'),
    'container_id': os.environ.get('COSMOS_CONTAINER', 'Items'),
}